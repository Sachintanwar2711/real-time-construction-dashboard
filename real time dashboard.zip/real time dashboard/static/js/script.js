// Simulate data update on the dashboard
function updateProgress() {
    fetch('/api/project_data')
        .then(response => response.json())
        .then(data => {
            updateTable(data);
            updateChart(data);
            updateStatusChart(data);
            updateTimeline(data);
        })
        .catch(error => console.error('Error fetching project data:', error));
}

// Update the project table with data
function updateTable(data) {
    const tableBody = document.querySelector('#projectTable tbody');
    tableBody.innerHTML = '';  // Clear existing rows
    data.forEach(project => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${project.id}</td>
            <td>${project.name}</td>
            <td>${project.status}</td>
            <td>${project.progress}</td>
            <td>${project.deadline}</td>
            <td>${project.teamMembers.join(", ")}</td>
            <td><button onclick="simulateProgress(${project.id})">Simulate Progress</button></td>
        `;
        tableBody.appendChild(row);
    });
}

// Update the progress chart with data
function updateChart(data) {
    const progressData = data.map(project => project.progress);
    const projectNames = data.map(project => project.name);

    const ctx = document.getElementById('projectProgressChart').getContext('2d');
    const progressChart = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: projectNames,
            datasets: [{
                label: 'Project Progress',
                data: progressData,
                backgroundColor: 'rgba(54, 162, 235, 0.5)',
                borderColor: 'rgba(54, 162, 235, 1)',
                borderWidth: 1
            }]
        },
        options: {
            scales: {
                y: {
                    beginAtZero: true,
                    max: 100
                }
            }
        }
    });
}

// Update the pie chart with project status data
function updateStatusChart(data) {
    const statusData = {
        Ongoing: 0,
        Completed: 0,
        Pending: 0
    };
    data.forEach(project => {
        if (project.status === 'Ongoing') {
            statusData.Ongoing += 1;
        } else if (project.status === 'Completed') {
            statusData.Completed += 1;
        } else if (project.status === 'Pending') {
            statusData.Pending += 1;
        }
    });

    const ctx = document.getElementById('projectStatusChart').getContext('2d');
    const statusChart = new Chart(ctx, {
        type: 'pie',
        data: {
            labels: ['Ongoing', 'Completed', 'Pending'],
            datasets: [{
                label: 'Project Status',
                data: [statusData.Ongoing, statusData.Completed, statusData.Pending],
                backgroundColor: ['rgba(75, 192, 192, 0.5)', 'rgba(153, 102, 255, 0.5)', 'rgba(255, 159, 64, 0.5)'],
                borderColor: ['rgba(75, 192, 192, 1)', 'rgba(153, 102, 255, 1)', 'rgba(255, 159, 64, 1)'],
                borderWidth: 1
            }]
        }
    });
}

// Update the project timeline
function updateTimeline(data) {
    const timelineContainer = document.getElementById('timeline');
    timelineContainer.innerHTML = '';  // Clear existing timeline

    data.forEach(project => {
        const projectLine = document.createElement('div');
        projectLine.classList.add('timeline-line');
        projectLine.style.width = `${project.progress}%`;
        projectLine.title = `${project.name}: ${project.progress}%`;

        timelineContainer.appendChild(projectLine);
    });
}

// Search through the project list
function searchProjects() {
    const input = document.getElementById('searchInput').value.toLowerCase();
    const rows = document.querySelectorAll('#projectTable tbody tr');

    rows.forEach(row => {
        const projectName = row.cells[1].textContent.toLowerCase();
        if (projectName.includes(input)) {
            row.style.display = '';
        } else {
            row.style.display = 'none';
        }
    });
}

// Simulate progress update for a project (random progress increase)
function simulateProgress(projectId) {
    fetch(`/api/update_project/${projectId}`)
        .then(response => response.json())
        .then(data => {
            alert('Project progress updated');
            updateProgress();  // Refresh the data
        })
        .catch(error => console.error('Error updating project:', error));
}
